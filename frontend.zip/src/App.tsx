import './App.scss';
import AppUsers from './components/AppUsers';

function App() {
	return (
		<>
			<AppUsers />
		</>
	);
}

export default App;
